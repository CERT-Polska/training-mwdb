import logging

from malduck.extractor import Extractor

log = logging.getLogger()


class Citadel(Extractor):
    family = "citadel"
    yara_rules = "citadel",
    overrides = ["zeus"]

    @Extractor.extractor("briankerbs")
    def citadel_found(self, p, addr):
        log.info('[+] `Coded by Brian Krebs` str @ %X' % addr)
        return {'family': 'citadel'}

    @Extractor.extractor
    def cit_salt(self, p, addr):
        salt = p.uint32v(addr - 8)
        log.info('[+] Found salt @ %X - %x' % (addr, salt))
        return {'salt': salt}
